router.post('/upload', function (req, res) {
  var multiparty = require('multiparty');
  var form = new multiparty.Form();
  var fs = require('fs');

  form.parse(req, function (err, fields, files) {
    var imgArray = files.imatges;


    for (var i = 0; i < imgArray.length; i++) {
      var newPath = './public/uploads/' + fields.imgName + '/';
      var singleImg = imgArray[i];
      newPath += singleImg.originalFilename;
      readAndWriteFile(singleImg, newPath);
    }
    res.send("File uploaded to: " + newPath);

  });

  function readAndWriteFile(singleImg, newPath) {

    fs.readFile(singleImg.path, function (err, data) {
      fs.writeFile(newPath, data, function (err) {
        if (err) console.log('ERRRRRR!! :' + err);
        console.log('Fitxer: ' + singleImg.originalFilename + ' - ' + newPath);
      })
    })
  }
})
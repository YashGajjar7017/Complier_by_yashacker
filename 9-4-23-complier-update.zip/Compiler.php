<?php

session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <style>
        body {
            background-image: url("gui.jpg");
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: 100% 100%;
        }

        h1 {
            color: white;
        }

        table {
            margin-left: 25%;
            margin-top: 1.5%;
        }
    </style>
</head>

<body>
        <div class="c_logout">
            <form action="logout.php" method="post">
                <input type="submit" value="Logout" name="logout">
            </form>
        </div>
</body>

</html>
<?php
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
    echo "<table>";
    echo "<tr>";
    echo "<td>" . "<h1>welcome:User</h1>" . "</td>";
    echo "</tr>";
    echo "</table>";
}else {

    $session = $_SESSION['username'];

    echo "<table>";
    echo "<tr>";
    echo "<td>" . "<h1>welcome:</h1>" . "</td>";
    echo "<td>" . "<h1>" . $session . "</h1>" . "</td>";
    echo "</tr>";
    echo "</table>";
}

?>
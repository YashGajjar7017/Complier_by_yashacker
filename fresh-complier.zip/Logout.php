<?php

$skip=$_POST['logout'];

if($skip){
    session_start();
    session_unset();
    session_destroy();
    header('location:Sign_In.html');
    exit;
}

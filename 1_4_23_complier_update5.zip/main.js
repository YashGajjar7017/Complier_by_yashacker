API_KEY = "34c8103e63msh909728bfda25be5p1bb0fbjsnd587398101bf"; // PLEASE DON'T SHARE 
// API_KEY = "cc6dcd8390msh2e162a8a61f0938p1a4717jsn3b68ec13545b"; // PLEASE DON'T SHARE 

var language_to_id = {
    "C": 50,
    "C++": 54,
    "Java": 62,
    "Python": 71,
};

function encode(str) {
    return btoa(unescape(encodeURIComponent(str || "")));
}

function decode(bytes) {
    var escaped = escape(atob(bytes || ""));
    try {
        return decodeURIComponent(escaped);
    } catch {
        return unescape(escaped);
    }
}

function errorHandler(jqXHR, textStatus, errorThrown) {
    $("#output").val(`${JSON.stringify(jqXHR, null, 4)}`);
    $("#run").prop("disabled", false);
}

function check(token) {
    $("#output").val($("#output").val() + "\nChecking submission status...");
    $.ajax({
        url: `https://judge0-ce.p.rapidapi.com/submissions/${token}?base64_encoded=true`,
        type: "GET",
        headers: {
            "x-rapidapi-host": "judge0-ce.p.rapidapi.com",
            "x-rapidapi-key": API_KEY
        },
        success: function (data, textStatus, jqXHR) {
            if ([1, 2].includes(data["status"]["id"])) {
                $("#output").val($("#output").val() + "\nStatus: " + data["status"]["description"]);
                setTimeout(function () {
                    check(token)
                }, 1000);
            } else {
                var output = [decode(data["compile_output"]), decode(data["stdout"])].join("\n").trim();
                $("#output").val(output);
                $("#run").prop("disabled", false);
            }
        },
        error: errorHandler
    });
}

function run() {
    $("#run").prop("disabled", true);
    $("#output").val("Creating submission...");
    $.ajax({
        url: "https://judge0-ce.p.rapidapi.com/submissions?base64_encoded=true",
        type: "POST",
        contentType: "application/json",
        headers: {
            "x-rapidapi-host": "judge0-ce.p.rapidapi.com",
            "x-rapidapi-key": API_KEY
        },
        data: JSON.stringify({
            "language_id": language_to_id[$("#lang").val()],
            "source_code": encode($("#source").val()),
            "stdin": encode($("#input").val()),
            "redirect_stderr_to_stdout": true
        }),
        success: function (data, textStatus, jqXHR) {
            $("#output").val($("#output").val() + "\nSubmission created.");
            setTimeout(function () {
                check(data["token"])
            }, 2000);
        },
        error: errorHandler
    });
}


$("body").keydown(function (e) {
    if (e.ctrlKey && e.keyCode == 13) {
        run();
    }
});

$("textarea").keydown(function (e) {
    if (e.keyCode == 9) {
        e.preventDefault();
        var start = this.selectionStart;
        var end = this.selectionEnd;

        var append = "    ";
        $(this).val($(this).val().substring(0, start) + append + $(this).val().substring(end));

        this.selectionStart = this.selectionEnd = start + append.length;
    }
});

// ----------------line-number-code------------------
$("#source").focus();

// text area
var codeEditor = document.getElementById('source');
var lineCounter = document.getElementById('lineCounter');

codeEditor.addEventListener('scroll', () => {
    lineCounter.scrollTop = codeEditor.scrollTop;
    lineCounter.scrollLeft = codeEditor.scrollLeft;
});

codeEditor.addEventListener('keydown', (e) => {
    let {
        keyCode
    } = e;
    let {
        value,
        selectionStart,
        selectionEnd
    } = codeEditor;
    if (keyCode === 9) { // TAB = 9
        e.preventDefault();
        codeEditor.value = value.slice(0, selectionStart) + '\t' + value.slice(selectionEnd);
        codeEditor.setSelectionRange(selectionStart + 2, selectionStart + 2)
    }
});

// ---------textarea-line-code--------------
var lineCountCache = 0;

function line_counter() {
    var lineCount = codeEditor.value.split('\n').length;
    var outarr = new Array();
    if (lineCountCache != lineCount) {
        for (var x = 0; x < lineCount; x++) {
            outarr[x] = (x + 1) + '.';
        }
        lineCounter.value = outarr.join('\n');
    }
    lineCountCache = lineCount;
}
codeEditor.addEventListener('input', () => {
    line_counter();
});

// -------------------------------@lineCounter1-------------------------------
$("#htmlTextarea").focus();

// text area
var codeEditor1 = document.getElementById('htmlTextarea');
var lineCounter1 = document.getElementById('lineCounter1');

codeEditor1.addEventListener('scroll', () => {
    lineCounter1.scrollTop = codeEditor1.scrollTop;
    lineCounter1.scrollLeft = codeEditor1.scrollLeft;
});

codeEditor1.addEventListener('keydown', (e) => {
    let {
        keyCode
    } = e;
    let {
        value,
        selectionStart,
        selectionEnd
    } = codeEditor1;
    if (keyCode === 9) { // TAB = 9
        e.preventDefault();
        codeEditor1.value = value.slice(0, selectionStart) + '\t' + value.slice(selectionEnd);
        codeEditor1.setSelectionRange(selectionStart + 2, selectionStart + 2)
    }
});

// ---------textarea-line-code--------------
var lineCountCache1 = 0;

function line_counter1() {
    var lineCount1 = codeEditor1.value.split('\n').length;
    var outarr = new Array();
    if (lineCountCache1 != lineCount1) {
        for (var x = 0; x < lineCount1; x++) {
            outarr[x] = (x + 1) + '.';
        }
        lineCounter1.value = outarr.join('\n');
    }
    lineCountCache1 = lineCount1;
}
codeEditor1.addEventListener('input', () => {
    line_counter1();
});

/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}

// navbar-setting

const body = document.querySelector("body"),
    nav = document.querySelector("nav"),
    modeToggle = document.querySelector(".dark-light"),
    searchToggle = document.querySelector(".searchToggle"),
    sidebarOpen = document.querySelector(".sidebarOpen"),
    siderbarClose = document.querySelector(".siderbarClose");

let getMode = localStorage.getItem("mode");
if (getMode && getMode === "dark-mode") {
    body.classList.add("dark");
}

// js code to toggle dark and light mode
modeToggle.addEventListener("click", () => {
    modeToggle.classList.toggle("active");
    body.classList.toggle("dark");

    // js code to keep user selected mode even page refresh or file reopen
    if (!body.classList.contains("dark")) {
        localStorage.setItem("mode", "light-mode");
    } else {
        localStorage.setItem("mode", "dark-mode");
    }
});

// js code to toggle search box
searchToggle.addEventListener("click", () => {
    searchToggle.classList.toggle("active");
});


//   js code to toggle sidebar
sidebarOpen.addEventListener("click", () => {
    nav.classList.add("active");
});

body.addEventListener("click", e => {
    let clickedElm = e.target;

    if (!clickedElm.classList.contains("sidebarOpen") && !clickedElm.classList.contains("menu")) {
        nav.classList.remove("active");
    }
});

// navbar-ended
// -------------------Sidebar1------------------
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
}
// -------------------Sidebar2------------------
function openNav1() {
    document.getElementById("mySidenav2").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav1() {
    document.getElementById("mySidenav2").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
}

// --------------------session-----------------------
function sessionChecker() {
    if (sessionStorage.getItem('session') == 1) {
        alert('success')
    }
    else if (sessionStorage.getItem('session') == 2) {
        alert('warning:session highjack')
    }
    else {
        sessionStorage.setItem('session', 0)
    }
}

// ---------------------Html LiveEditor-------------------
function refresh() {
    var textContent = document.getElementById('htmlTextarea').value;
    document.getElementById('htmlTextarea1').srcdoc = textContent;
}

// ---------------------On ready(Jqueary)------------------------
$(document).ready(function () {
    // $('.user').hide();
})

// $('#login').text('Logout');
//         $('.user').show();

// --------------------Logout change code..------------------------
function loginCode() {
    if (localStorage.getItem('loginCode') == 1) {
        // let login1 = document.getElementById('login');
        $('#login').hide();
        $('.user').show();
    }
    else if (localStorage.getItem('loginCode') == 2) {
        $('#login').hide();
        $('.user').show();
    }
    else {
        window.location.href = 'Sign_Up.html';
        localStorage.setItem('loginCode', 0)
    }
}

function LogoutToLogin() {
    // $('#login').text('Logout');
    loginCode()
    localStorage.setItem('loginCode', 1)
}

function LoginTologout() {
    let logout = document.getElementById('')
    localStorage.setItem('loginCode', 2)
    loginCode()
}

// ----------------Fetch username-----------------
let username = document.getElementById('username');
let userData = sessionStorage.getItem('userName');

username.innerText += userData;

// -------------Extend-Line-----------
const box = document.getElementById("source");
box.style.height = box.scrollHeight + "px";

const box1 = document.getElementById("output");
box1.style.height = box1.scrollHeight + "px";

const box2 = document.getElementById("input")
box2.style.height = box2.scrollHeight + "px";

// --------------Stop function-------------
function stop() {
    $("#output").val("Code exited...\n =>Error code 1 \n =>code has been stopped");
}

// ---------------Print function-------------------
function printPageArea(areaID) {
    var printContent = document.getElementById(areaID).innerHTML;
    var originalContent = document.body.innerHTML;
    document.body.innerHTML = printContent;
    window.print();
    document.body.innerHTML = originalContent;
}

// ------------------------Download_File_Code:-----------------------
const downloadFile = () => {
    const link = document.createElement("a");
    const content = document.querySelector("#source").value;
    const file = new Blob([content], { type: 'text/plain' });

    link.href = URL.createObjectURL(file);
    a = document.getElementById('lang').value;
    if (a == 'C') {
        b = 'c';
    }
    else if (a == 'C++') {
        b = 'cpp';
    }
    else if (a == 'Python') {
        b = 'py';
    }
    else if (a == 'Java') {
        b = 'java';
    }
    else if (a == 'Html') {
        b = 'html';
    }
    else {
        // b = 'bat';
        alert('Please select the language first or languague may not be supported for download..')
    }

    link.download = "The_Byter's_Machine." + b;
    link.click();

    URL.revokeObjectURL(link.href);
};


//*************** */ Language selector Code:*********************
let LangData = localStorage.getItem('lang');

function LangSelector() {
    var lang = document.getElementById('lang').value;
    localStorage.setItem('lang', 'C');
    localStorage.setItem('editorChange', 1);

    // ---------------C-------------
    if (lang == 'C') {
        $('#htmlEditor,#htmlTextarea,#htmlTextarea1,#lineCounter1,.kali').fadeOut(900)
        $('#lineCounter,#IO,#source').delay(700).fadeIn();
        document.getElementById('source').innerHTML =
            `#include<stdio.h>
void main()
{
    printf("Hello world...");
}`
    }

    // ---------------cpp---------------
    else if (lang == 'C++') {
        $('#htmlEditor,#htmlTextarea,#htmlTextarea1,#lineCounter1,.kali').fadeOut(900)
        $('#lineCounter,#IO,#source').delay(700).fadeIn();
        localStorage.setItem('lang', 'Cpp');
        localStorage.setItem('editorChange', 2);
        document.getElementById('source').innerHTML =
            `#include <iostream>
using namespace std;

int main()
{
    cout << "Hello World";
    return 0;
}`;

    }


    // ---------------python--------------- 
    else if (lang == 'Python') {
        $('#htmlEditor,#htmlTextarea,#htmlTextarea1,#lineCounter1,.kali').fadeOut(900)
        $('#lineCounter,#IO,#source').delay(700).fadeIn();

        localStorage.setItem('lang', 'Python');
        localStorage.setItem('editorChange', 3);

        document.getElementById('source').innerHTML =
            `print("hello world")`;

    }

    // ---------------java---------------
    else if (lang == 'Java') {
        $('#htmlEditor,#htmlTextarea,#htmlTextarea1,#lineCounter1,.kali').fadeOut(900)
        $('#lineCounter,#IO,#source').delay(700).fadeIn();

        localStorage.setItem('lang', 'Java');
        localStorage.setItem('editorChange', 4);

        document.getElementById('source').innerHTML =
            `class Test
{
    public static void main(String []args)
    {
        System.out.println("My First Java Program.");
    }
};`;
    }

    // ---------------html---------------
    else if (lang == 'Html') {
        $('#lineCounter,#IO,#source').fadeOut(900)
        $('#htmlEditor,#htmlTextarea,#htmlTextarea1,#lineCounter1').delay(700).fadeIn(); //#lineCounter

        localStorage.setItem('lang', 'Html');
        localStorage.setItem('editorChange', 4);

    }
    // ---------------hacking---------------
    else if (lang == 'Hacking') {
        $('#lineCounter,#IO,#source,#htmlEditor,#htmlTextarea,#htmlTextarea1,#lineCounter1').fadeOut(900);
        $('.kali').delay(700).fadeIn();

        localStorage.setItem('lang', 'Hacking');
        localStorage.setItem('editorChange', 5);

        setTimeout(window.location.href = 'http://192.168.1.8:8888', 2000);

    }
    else {
        localStorage.removeItem("lang");
        localStorage.setItem('editorChange', 0);
    }
}

// -----------------------Font-size----------------------

let textarea = document.getElementById("source");
// let size = document.getElementById('fontsize').value;
// console.log(size);
// textarea.style.fontSize = `${size}px`;

// -----------------------Background----------------------
let color1 = document.getElementById('colorPicker');
color1.addEventListener(function () {
    let color = document.getElementById('color1').value;
    setTimeout(textarea.style.backgroundColor = color, 100)
    console.log(color);

})
// ----------------------Water remainder------------------
let waterReminder = localStorage.getItem('waterLiters');

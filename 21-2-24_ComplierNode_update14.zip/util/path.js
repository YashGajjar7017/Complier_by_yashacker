// This is module is use for path module only 
const path = require('path');

module.exports = path.dirname(process.mainModule.filename);